import pickle
from sklearn.model_selection import train_test_split   # splitting data
from sklearn.preprocessing import StandardScaler  
from sklearn.neural_network import MLPClassifier 
from sklearn.metrics import accuracy_score, f1_score
import numpy as np
from sklearn import svm   
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.ensemble import RandomForestClassifier   # RANDOM FOREST algorithm
from sklearn.linear_model import LogisticRegression   # LOGISTIC REG algorithm
from sklearn.cluster import AgglomerativeClustering 
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF
from sklearn.ensemble import AdaBoostClassifier
import time

#opening the pickle file
infile = open('feature_df.pkl','rb')
feat_data = pickle.load(infile)
infile.close()

feat_data = feat_data.dropna()
#print(feat_data)
#print(feat_data)

X = feat_data.loc[:,'DWT_var':'Fractal_dimension']
Y = feat_data['Class']

#x_test_1 = feat_data.loc[0, 'DWT_var':'rate']
#y_test_1 = feat_data.loc[0,'Class']
#print(x_test_1)
#print(y_test_1)

X_train, X_test, y_train, y_test = train_test_split(X,Y,test_size=0.3,random_state= 0)
stdsc = StandardScaler()            # applying standardization

X_train_std = stdsc.fit_transform(X_train)#fit and transform the training 
                                          #data    \
filename = 'standardscaler.pkl'
pickle.dump(stdsc, open(filename, 'wb'))



X_test_std = stdsc.transform(X_test)
#print(X_train_std)
#print(y_train)


means = stdsc.mean_ 
var = stdsc.var_
#print(means.shape)


#print(y_test)


#print(list(y_test))
#The parameters were extracted upon hyperparameter tuning\
def g_p_c(x_train_std, y_train,x_test_std,y_test):
    start_time = time.time()
    kernel = 1.0 * RBF(1)
    model = GaussianProcessClassifier(kernel=kernel, random_state=0)
    model.fit(x_train_std,y_train)
    y_pred = model.predict(x_test_std)
    print("Execution Time :" ,(time.time() - start_time))
    
    filename = 'gpc_model_trained_1.pkl'
    pickle.dump(model, open(filename, 'wb'))
    
    print('GAUSSIAN PROCESS CLASSIFIER(GPC) ALGORITHM....')
    print(round((accuracy_score(y_test,y_pred))*100,2),'%')
    p_confusion_matrix(y_test, y_pred)
    print(('*')*50)

def ada_boost(x_train_std, y_train,x_test_std,y_test):
    start_time = time.time()
    model = AdaBoostClassifier(random_state=0)
    model.fit(x_train_std,y_train)
    y_pred = model.predict(x_test_std)
    print("Execution Time :" ,(time.time() - start_time))
    
    filename = 'adaboost_model_trained_1.pkl'
    pickle.dump(model, open(filename, 'wb'))
    
    print('ADABOOST CLASSIFIER ALGORITHM....')
    print(round((accuracy_score(y_test,y_pred))*100,2),'%')
    p_confusion_matrix(y_test, y_pred)
    print(('*')*50)
    
def h_c(x_train_std, y_train,x_test_std,y_test):
    start_time = time.time()
    hc = AgglomerativeClustering(n_clusters = 2, affinity = 'euclidean', linkage ='ward')
    x_combined_std = np.vstack((x_train_std, x_test_std))
    y_combined = np.hstack((y_train, y_test))
    
    y_hc=hc.fit_predict(x_train_std)
    print("Execution Time :" ,(time.time() - start_time))
    
    filename = 'hc_model_trained_1.pkl'
    pickle.dump(hc, open(filename, 'wb'))
    
    print('HIERARCHICAL CLUSTERING ALGORITHM....')
    print(round((accuracy_score(y_train,y_hc))*100,2),'%')
    
    p_confusion_matrix(y_train, y_hc)
    print(('*')*50)
#The parameters were extracted upon hyperparameter tuningdef l_r(x_train_std, y_train,x_test_std,y_test):
def l_r(x_train_std, y_train,x_test_std,y_test):    
    start_time = time.time()
    lr = LogisticRegression(C=10 , solver = 'liblinear',
                            multi_class = 'ovr', random_state = 0)
    lr.fit(x_train_std,y_train)
    print("Execution Time :" ,(time.time() - start_time))
    filename = 'lr_model_trained_1.pkl'
    pickle.dump(lr, open(filename, 'wb'))

#the value of datasets are predicted
    y_pred = lr.predict(x_test_std)
    confusion_matrix(y_test, y_pred)
    print("LOGISTIC REGRESSION ALGORITHM......")
    print("The Accuracy score of the Logistic Regression algorithm is:", 
          round((accuracy_score(y_test,y_pred))*100,2),'%')
    p_confusion_matrix(y_test, y_pred)
    print(('*')*50)


def Support_vec(x_train_std, y_train,x_test_std,y_test):
    start_time = time.time()
    s_v_m = svm.SVC(C=1.0, kernel='sigmoid', degree=3, gamma='scale', coef0=0.0, 
                    shrinking=True, probability=False, tol=1e-3,cache_size=200,
                    class_weight='balanced', verbose=False, max_iter=-1,
                    decision_function_shape='ovr', 
                    random_state=None)

    s_v_m.fit(x_train_std,y_train)

#the value of datasets are predicted
    y_pred = s_v_m.predict(x_test_std)
    print("Execution Time : " ,(time.time() - start_time))
##    y_t = (list(y_test))
##    y_p = (list(y_pred))
##    for i in range(len(y_p)):
##        print(y_t[i],y_p[i])
#
    print("SUPPORT VECTOR MACHINE ALGORITHM......")
    print("The Accuracy score of the SVM algorithm is:", 
          round((accuracy_score(y_test,y_pred))*100,2),'%')
#
## combine the train and test data
#    x_combined_std = np.vstack((x_train_std, x_test_std))
#
#    y_combined = np.hstack((y_train, y_test))
#
## check results on combined data
#    y_combined_pred = s_v_m.predict(x_combined_std)
#
#    print('The Combined Accuracy of Support Vector Machine algorithm is:', 
#          round(accuracy_score(y_combined, y_combined_pred),3)*100,'%',"\n\n")
    p_confusion_matrix(y_test, y_pred)
    print(('*')*50)

    filename = 'svm_model_trained_1.pkl'
    pickle.dump(s_v_m, open(filename, 'wb'))

def r_fores(x_train, y_train,x_test,y_test):
    start_time = time.time()
    forest = RandomForestClassifier(n_estimators=100, criterion='gini',
                                    max_depth=None, min_samples_split=2, 
                                    min_samples_leaf=1,
                                    min_weight_fraction_leaf=0.0
                                    , max_features='auto', max_leaf_nodes=None, 
                                    min_impurity_decrease=0.0,
                                    min_impurity_split=None, bootstrap=True,
                                    oob_score=False, n_jobs=None, 
                                    random_state=None, verbose=0,
                                    warm_start=False, class_weight=None)

    forest.fit(x_train, y_train)
    print("Execution Time :" ,(time.time() - start_time))
    filename = 'rf_model_trained_1.pkl'
    pickle.dump(forest, open(filename, 'wb'))

#the value of datasets are predicted
    y_pred = forest.predict(x_test)

    print("RANDOM FOREST ALGORITHM......")
    print('The Accuracy score of the Random forest algorithm is:' , 
          round((accuracy_score(y_test,y_pred))*100,2),'%')
    p_confusion_matrix(y_test, y_pred)
    print(('*')*50)

    
def mc(x_train, y_train,x_test,y_test):
        
    start_time = time.time()
    model = MLPClassifier(hidden_layer_sizes=(100),activation ='logistic',
                                  max_iter = 2000, alpha= 0.0001,solver ='adam',
                                  tol = 0.0001,random_state = None,
                                  learning_rate = 'constant')
    model.fit(x_train, y_train)
    

    filename = 'mc_model_trained_1.pkl'
    pickle.dump(model, open(filename, 'wb'))
    y_pred = model.predict(x_test)
    print("Execution Time :" ,(time.time() - start_time))
    
    #Test accuracy is found out
    ac_scor = round( (accuracy_score(y_test, y_pred) * 100) )
    
    print('MULTILAYER PERCEPTRON ALGORITHM....')
    print('Accuracy achieved for the MultiLayer Perceptron is:',ac_scor, '%')
    print('\n')
    p_confusion_matrix(y_test, y_pred)
    print(('*')*50)
        
def p_confusion_matrix(y_true, y_pred):
    cm = confusion_matrix(y_true, y_pred)
    TP,FP,FN,TN = cm[0][0],cm[0][1],cm[1][0], cm[1][1]
    FAR = round((FP)/(FP+TN),3)
    FRR = round((FN)/(TP+FN),3)
    HTER = round((FAR + FRR)/2,3)
    f_1 = round((f1_score(y_true,y_pred) * 100))
    print('False Accept Rate(FAR):', FAR )
    print('False Reject Rate(FRR):', FRR )
    print('Half Total Error(HTER):', HTER)
    print('F1 score:', f_1)

if __name__ == '__main__':
    
    
 
    
    r_fores(X_train_std, y_train,X_test_std,y_test)
    Support_vec(X_train_std, y_train,X_test_std,y_test)
    l_r(X_train_std, y_train,X_test_std,y_test)
    h_c(X_train_std, y_train,X_test_std,y_test)
    mc(X_train_std, y_train,X_test_std,y_test)
    ada_boost(X_train_std, y_train,X_test_std,y_test)
    g_p_c(X_train_std, y_train,X_test_std,y_test)
     
#     X = [-2.85700939e-01, -2.46354099e-02 ,-7.10392844e-01, -5.98951577e-01,-4.02632682e-01, 8.19510228e-01]]
    
#     filename = 'svm_model_trained.pkl'
#     loaded_model = pickle.load(open(filename, 'rb'))
##     result = loaded_model.score(X_test_std[1].reshape(1,-1), y_test[1].reshape(-1,1))
#     result_pred = loaded_model.predict(X_test_std[-1].reshape(1,-1))
##     print(result)
#     print(result_pred)
     
     
