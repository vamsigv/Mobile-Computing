#Importing necessary packages...
import numpy as np
import scipy.io
import pandas as pd



###############################################################################
#Viewing the Data
mat = scipy.io.loadmat('Dataset1.mat')

data = mat['Raw_Data']

#Creating the dataframe for live dataset
#Converting the data to a Pandas Dataframe for processing...
data_list = []
for index,i in enumerate(data):
    for j in i:
        temp_list = []
        temp_list.append(index+1)
        temp_list.append(0)
        for k in j:
            temp_list.append(k)
        data_list.append(temp_list)

#Class-0 = Live Dataset
#Class-1 = Sample Attack 
df_live = pd.DataFrame(data_list) 
df_live.rename(columns = {0:'subjects',1:'Class'}, inplace = True)
#print(df_live)

###############################################################################
#Creating the dataframe for fake dataset
mat_fake = scipy.io.loadmat('sampleAttack.mat')
data_fake = mat_fake['attackVectors']
data_list_fake = []
for index,i in enumerate(data_fake):
    for im,j in enumerate(i):
        for k in j:
            temp_list = []
#            temp_list.append(index+1)
            temp_list.append(im+1)
            temp_list.append(1)
            for b in (list(k)*4):
                temp_list.append(b)
            data_list_fake.append(temp_list)
    
    
df_fake = pd.DataFrame(data_list_fake)  
df_fake.rename(columns = {0:'subjects',1:'Class'}, inplace = True) 
#print(df_fake)

#Final Dataframe
final_df = pd.concat([df_live,df_fake], axis = 0)
final_df = final_df.iloc[:,0:482]

temp_df_features = final_df.iloc[:,2:19202]
temp_df_cs = final_df[['subjects','Class']]

import pickle

with open("brain_df.pkl", "wb") as file:
    pickle.dump(final_df, file)

#def normalize(row):
#    for index, i in enumerate(row):
#        num = (i - row.mean())
#        den =row.std()
#        if den != 0:
#            row[index] = num/den
#        else:
#            den += 1
#            row[index] = num/den
#            
##        row[index] =  ((i - np.mean(row)) /(max(row) - min(row)))
#    return row
#    
#normalized_df = (final_df.iloc[:,2:19202]).apply(lambda row : normalize(row), axis=1)
