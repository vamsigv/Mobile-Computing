import pickle
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.utils import shuffle
import feature_extraction

from scipy.io import savemat
infile = open('brain_df.pkl','rb')
raw_data = pickle.load(infile)
infile.close()
#print(raw_data)

#Signal Analysis for one single data
def signal_analysis():
    inp= np.array(raw_data.iloc[0,2:482])
    
    t = np.linspace(1,480,480)
    
    plt.plot(t, inp)
    plt.title('Signal')
    plt.ylabel('Voltage (V)')
    plt.xlabel('Time (s)')
    plt.show()
    
    x_watts = inp ** 2
    
    
    
    # Set a target SNR
    target_snr_db = 20
    # Calculate signal power and convert to dB 
    sig_avg_watts = np.mean(x_watts)
    sig_avg_db = 10 * np.log10(sig_avg_watts)
    # Calculate noise according to [2] then convert to watts
    noise_avg_db = sig_avg_db - target_snr_db
    noise_avg_watts = 10 ** (noise_avg_db / 10)
    # Generate an sample of white noise
    mean_noise = 0
    noise_volts = np.random.normal(mean_noise, np.sqrt(noise_avg_watts), len(x_watts))
    # Noise up the original signal
    y_volts = inp + noise_volts
    
    # Plot signal with noise
    plt.plot(t, y_volts)
    plt.title('Signal with noise')
    plt.ylabel('Voltage (V)')
    plt.xlabel('Time (s)')
    plt.show()

signal_analysis()


original = np.array(raw_data.iloc[:,2:482])
df_common = raw_data.loc[:,'subjects':'Class']
#print(original.shape)
noise = np.random.normal(0, .1, original.shape)
new_signal = original + noise
print(new_signal.shape)


df_noise_gen = pd.DataFrame(new_signal)
df_common.reset_index(drop=True, inplace=True)
df_noise_gen.reset_index(drop=True, inplace=True)
final_df = pd.concat([df_common,df_noise_gen],axis = 1)
final_df = shuffle(final_df)

noise_feature_df = feature_extraction.main(final_df)
noise_feature_df.dropna()

print(noise_feature_df)
temp = noise_feature_df.loc[:,'DWT_var':'Fractal_dimension']
print(temp)
temp = temp.to_numpy()
fake_data = {'data':''}
print(temp)
y_test = noise_feature_df['Class']
fake_data['data'] = temp
print(temp.shape)
print(fake_data)
savemat("fake_signal_1.mat", fake_data)