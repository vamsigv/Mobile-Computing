# Mobile_Computing_BrainSignal
To detect the liveness of the brain signal
