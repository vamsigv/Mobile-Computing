import pickle
import numpy as np
import tsfresh
import math
import pywt
import pandas as pd
import librosa
import pyeeg


from sklearn.preprocessing import PolynomialFeatures
from tsfresh import extract_relevant_features
from scipy.stats import skew, kurtosis
from sklearn.model_selection import train_test_split 
from sklearn.preprocessing import StandardScaler       # scaling data
from sklearn.utils import shuffle
from sklearn.preprocessing import PolynomialFeatures


class features():
    def zero_crossing(line):
        gradient = np.concatenate([[0], np.diff(-line)])
        p_n_sign = np.sign(gradient[0:-1]*gradient[1:])
        points = np.where(p_n_sign<0)[0]
        if len(points) > 0:
            crossing_point = max(gradient[points + 1] - gradient[points])
            
        else:
            crossing_point = 0
        
        change_val = (np.sum(np.abs(np.sign(gradient[1:])-np.sign(gradient[:-1])))) / (2*len(gradient))
        return (crossing_point ,change_val)
    
    #DWT - bior
    def dwt(line):
        #Approximation and Detail co-efficients
        #We are considering the Detail co-eff
        (cA, cD) = pywt.dwt(line, 'bior3.5')
        return (np.var(cD) , skew(cD) , kurtosis(cD))
        
    #Fourier Transform- Beta band    
    def fft_beta(line):
        sampling_rate = 160
        fft_val = np.absolute(np.fft.rfft(line))
        fft_freq = np.fft.rfftfreq(len(line), 1.0/sampling_rate)
    
    
        eeg_bands = {'Beta': (13, 30)}
                      
        freq_ix = np.where((fft_freq >= eeg_bands['Beta'][0]) & (fft_freq <= eeg_bands['Beta'][1]))[0]
        beta_val= np.mean(fft_val[freq_ix])
        return beta_val
    
    def hurst(line):
        hrst = pyeeg.hurst(line)
        return hrst
    def p_f_d(line):
        PFD= pyeeg.pfd(line)
        return PFD
        
    

            

def main(df_data):
    df_feat = df_data.iloc[:,:2]
    df_data = df_data.iloc[:,2:482]
   
    
    
    df_feat[['DWT_var', 'DWT_skew', 'DWT_kurt']]= df_data.apply(lambda line: features.dwt(line), axis = 1, result_type = 'expand')
    df_feat['FFT_beta']= df_data.apply(lambda line: features.fft_beta(line), axis = 1)
    df_feat[['crossing','rate']]= df_data.apply(lambda line: features.zero_crossing(line), axis = 1, result_type = 'expand')
    df_feat['Hurst_exp'] = df_data.apply(lambda line: features.hurst(line), axis = 1)
    df_feat['Fractal_dimension'] = df_data.apply(lambda line: features.p_f_d(line), axis = 1)
    
#    poly = PolynomialFeatures(degree=2)
#    print((poly.fit_transform(df_feat.iloc[:,2:])).shape)
#    
    
    df_feat = shuffle(df_feat)
    with open("feature_df.pkl", "wb") as file:
        pickle.dump(df_feat, file)
        
#    print(df_feat)
    

#    print(p2)
    
    print(df_feat)
    return df_data

#    print(df_new)
    
if __name__ == '__main__':
    
    
    #opening the pickle file
    infile = open('brain_df.pkl','rb')
    df_data = pickle.load(infile)
    infile.close()
    df = main(df_data)
    
#    df_data = df_data.iloc[0,:]
##    
#    df = (pd.DataFrame(df_data)).T
#    print(type(df))
#    print(df)
#    df = main(df)
#    arr = df.to_numpy()
#    print(arr)
#    
#    
#    filename = 'standardscaler.pkl'
#    sc = pickle.load(open(filename, 'rb'))
#    sc.transform(arr.reshape(-1,1))
#    
