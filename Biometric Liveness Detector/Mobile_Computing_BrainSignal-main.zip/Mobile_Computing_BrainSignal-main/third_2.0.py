import numpy as np
from scipy.io import savemat
import scipy.io
from flask import Flask, request, send_from_directory, jsonify, request, render_template, redirect, url_for
import time
import werkzeug
import pickle
import os
import ML
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import pickle
import pandas as pd
import ML
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, confusion_matrix
from scipy.io import savemat
import scipy.io
from numpy import *
from sklearn.metrics import accuracy_score, f1_score
from pathlib import Path



app = Flask(__name__)
app.config["FILE_UPLOADS"] = "C:\MCProject"
DIRECTORY = "C:\Training"
filename = "test_multiple.mat"
#Singleinput = "test.mat"

    
final_result = [None]



@app.route("/download")
def get_file():
    print('File access')
    return send_from_directory(DIRECTORY, filename, as_attachment=True)

'''
@app.route("/test", methods=['GET'])
def get_test():
    return jsonify({"data": "test"})
'''

@app.route('/uploadfile', methods=['GET','POST'])
def handle_request():
    file_ids = list(request.files)
    print("\nNumber of received files: ", len(file_ids))
    image_num = 1
    result = []
    for file_id in file_ids:
        print("\nSaving File ", str(image_num), "/", len(file_ids))
        input_file = request.files[file_id]
        filename = werkzeug.utils.secure_filename(input_file.filename)
        print("Input Filename : " + input_file.filename)
        timestr = time.strftime("%Y%m%d-%H%M%S")
        fname = timestr + '_' + filename
        input_file.save(os.path.join(app.config["FILE_UPLOADS"],fname))
        input_file_path = os.path.join(app.config["FILE_UPLOADS"],fname)
        
        
        result.append(test(input_file_path, fname))
        #print(result)
        #result_dict = [{"success": 1, "message": "Uploaded successfully!"}]
        #return jsonify(result_dict)
        # result = results(filename)  # The result is being  stored in this parameter

    #print("\n")
    #result_dict = [{"success": 1, "message": "Uploaded successfully!"}]
    #print(result)
    final_result[0] = jsonify(result)
    return jsonify(result)

@app.route('/get_data', methods=['GET'])
def get_data():
    return final_result[0]


# app = Flask(__name__)
# model = pickle.load(open('model.pkl', 'rb'))

#
'''
def results(filename):  # function to fetch the results.

    data = request.get_json(force=True)  # load file using pandas ?
    prediction = model.predict([np.array(list(data.values()))])  # give me sample input values to the model

    output = prediction[0]  # should know the emodel results.
    return jsonify(output)

'''

means = ML.means
var = ML.var


def scale_data(array, means=means, stds=var ** 0.5):
    return (array - means) / stds

#@app.route("/test", methods=['GET', 'POST'])
def test(input_file_path, fname):
    #input_file_path = request.args['input_file_path']
    #fname = request.args['fname']
    print('Processing....')
    print(input_file_path)
    mat = scipy.io.loadmat(input_file_path)
    data = mat['data']
    nptest = np.array(data.shape)
    size = nptest[0]
    if size > 1:
        y_test = ML.y_test
    else:
        y_test = ML.y_test[873]
    
    sc = StandardScaler()
    scale_new_data = sc.fit_transform(data)

#    print(scale_new_data)

    models = [ 'rf_model_trained_1.pkl', 'svm_model_trained_1.pkl', 'hc_model_trained_1.pkl','lr_model_trained_1.pkl',
              'mc_model_trained_1.pkl','adaboost_model_trained_1.pkl','gpc_model_trained_1.pkl']

    results = []
    keys = ["Random Forest", "SVM","hc", "Logistic Regression", "MC","adaboost","GPC" ]
    key_idx = 0
    for model in models:
#        print(model, key_idx)
        if model == 'hc_model_trained_1.pkl' and size==1 :
            continue
        
        result_dict = {}
        loaded_model = pickle.load(open(model, 'rb'))
        
        if model == 'hc_model_trained_1.pkl':
            
            y_pred = loaded_model.fit_predict(scale_new_data)
            
        else:
            
            y_pred = loaded_model.predict(scale_new_data)
         
        if size>1:
        
            #Metrics calculation
            acc = round((accuracy_score(y_test,y_pred))*100,2)
            cm = confusion_matrix(y_test, y_pred)
            TP,FP,FN,TN = cm[0][0],cm[0][1],cm[1][0], cm[1][1]
            FAR = round((FP)/(FP+TN),3)
            FRR = round((FN)/(TP+FN),3)
            HTER = round((FAR + FRR)/2,3)
            f_1 = round((f1_score(y_test,y_pred) * 100))
            result_dict["Model_Name"] = keys[key_idx]
            result_dict["Accuracy"] = acc
            result_dict["F1_Score"] = f_1
            result_dict["False_Acceptance"] = FAR
            result_dict["False_Reject_Rate"] = FRR
            result_dict["Half_Total_Error"] = HTER
            result_dict["Liveness"] = -1
            

        else:
            result_dict["Model_Name"] = keys[key_idx]
            result_dict["F1_Score"] = -1
            result_dict["Accuracy"] = -1
            result_dict["False_Acceptance"] = -1
            result_dict["False_Reject_Rate"] = -1
            result_dict["Half_Total_Error"] = -1
            result_dict["Liveness"] = y_pred
            
        results.append(result_dict)
        
            #print(results)
        key_idx += 1
    
    return get_best_model(results, fname, size)
    #return jsonify(results)

def get_best_model(results_array, fname, size):
    
    if size>1:
        max = 0
        #print(results_array)
        for result in results_array:
            print('*'*100)
            print(result)
            
            if result["Accuracy"] > max:
                max = result["Accuracy"]
                max_index = results_array.index(result)

        return results_array[max_index]

    else:
        count = {1:0, 0:0}
        best_model = { "Model_Name" : -1,"F1 Score":-1, "Accuracy": -1, "False_Acceptance": -1 , "False_Reject_Rate": -1, "Half_Total_Error": -1, "Liveness": -1}
        for result in results_array:
            if result["Liveness"] == 1:
                count[1] = count[1] + 1
            elif result["Liveness"] == 0:
                count[0] = count[0] + 1
        if count[0] > count[1]:
            best_model["Liveness"] = 0
        else:
            best_model["Liveness"] = 1
        print(count)
        return best_model
        


if __name__ == "__main__":
    y_test = ML.y_test
    app.run(host='0.0.0.0')
